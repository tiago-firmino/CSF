# The best hacking scripts in the world

Enjoy!

First install the requirements like this `pip install -r requirements.txt`, if you don't already have them.

If you need help to use these scripts, then you're not a real hacker :P

PirateMajima