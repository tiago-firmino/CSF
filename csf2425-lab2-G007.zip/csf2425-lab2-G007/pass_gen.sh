#!/bin/bash
python3.8 ~/backups/obfuscator $1
